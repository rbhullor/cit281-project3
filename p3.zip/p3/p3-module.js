function validDenomination(coin) {
    const validDenominations = [1, 5, 10, 25, 50, 100];
    return validDenominations.indexOf(coin) !== -1;
  }
  
  function valueFromCoinObject(obj) {
    const { denom = 0, count = 0 } = obj;
    return denom * count;
  }
  
  function valueFromArray(arr) {
    return arr.reduce((total, obj) => total + valueFromCoinObject(obj), 0);
  }
  
  function coinCount(...coinage) {
    return valueFromArray(coinage);
  }

  const coin = {
    denom: 25,
    count: 3
  };

  const isValidDenomination = validDenomination(coin.denom);
console.log("Is valid denomination:", isValidDenomination);

const coinValue = valueFromCoinObject(coin);
console.log("Coin value:", coinValue);

const coinArray = [
    { denom: 25, count: 3 },
    { denom: 10, count: 2 },
    { denom: 1, count: 7 }
  ];
  const totalValue = valueFromArray(coinArray);
  console.log("Total value:", totalValue);

const totalValueFromArgs = coinCount({ denom: 5, count: 3 }, { denom: 10, count: 2 });
console.log("Total value from arguments:", totalValueFromArgs);
console.log("{}", coinCount({ denom: 5, count: 3 }));
console.log("{}s", coinCount({ denom: 5, count: 3 }, { denom: 10, count: 2 }));
const coins = [{ denom: 25, count: 2 }, { denom: 1, count: 7 }];
console.log("...[{}]", coinCount(...coins));
console.log("[{}]", coinCount(coins));